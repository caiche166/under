package org.apache.hadoop.pr;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.StringTokenizer;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class PageRank {

  public static class MyMapper 
       extends Mapper<Object, Text, Text, Text>{
    private Text id = new Text();
    public void map(Object key, Text value, Context context
                    ) throws IOException, InterruptedException {
		  String line = value.toString();
//因为hadoop在reduce写入hdfs的时候会生成三个文件_SUCCESS,_logs,part-r-00000,而迭代时能用到的只有第三个，所以需要判断读出来的是不是有效，这里通过判断第一个字符是不是数字简单地判断了一下，用startsWith是不行的，它不接受正则表达式。
		  if(line.substring(0,1).matches("[0-9]{1}"))
		  {
			  boolean flag = false;
			  if(line.contains("_"))
			  {
				line = line.replace("_","");
				flag = true;
			  }
//这个地方很重要，也许你会问为什么根据\t来split而不是空格，原因是context.write在写入的时候是在key/value对中加入了一个\t，为方便迭代处理，因此先这样split。
                          String[] values = line.split("\t");
			  Text t = new Text(values[0]);
			  String[] vals = values[1].split(" ");
//因为下次迭代的时候还会用到url，所以需要将这些url也保留下来，但是为了方便reduce计算的时候区别，加一个特殊符号_做标记。
                          String url="_";
			  double pr = 0;
			  int i = 0;
			  int num = 0;
//这个地方的为什么要加个flag变量下面的reduce里头再解释。
			  if(flag)
			  {
				i=2;
				pr=Double.valueOf(vals[1]);
				num=vals.length-2;
			  }
			  else
			  {
				i=1;
				pr=Double.valueOf(vals[0]);
				num=vals.length-1;
			  }
			  for(;i<vals.length;i++)
			  {
				url=url+vals[i]+" ";
				id.set(vals[i]);
				Text prt = new Text(String.valueOf(pr/num));
				context.write(id,prt);
			  }
			  context.write(t,new Text(url));
		}
    }
  }
  
  public static class MyReducer 
       extends Reducer<Text,Text,Text,Text> {
    private Text result = new Text();
    private Double pr = new Double(0);
    public void reduce(Text key, Iterable<Text> values, 
                       Context context
                       ) throws IOException, InterruptedException {
      double sum=0;
      String url="";
      for(Text val:values)
      {
//发现_标记则表明是url，否则是外链pr，要参与计算
		if(!val.toString().contains("_"))
		{
		  sum=sum+Double.valueOf(val.toString());
		}
		else
		{
		  url=val.toString();
		}
      }
      pr=0.15+0.85*sum;
      String str=String.format("%.3f",pr);
//这个地方纠结了我最久，原本pr是个double型数，但是我转成str之后，发现输出时前面多了一列比如原本应该是输出0.575，结果却是0.1500.575，而且我加空格后是0.150 0.575，这个我到现在都没明白这到底是因为什么，所以我只能让它写入结果文件，然后再下次迭代的时候再进行预处理，也就是上面map阶段的那个flag的作用。
      result.set(new Text(str+" "+url));
      context.write(key,result);
    }
  }

  public static void main(String[] args) throws Exception {
    String paths="/user/root/out/00";
    String path1=paths;
    String path2="";
//实验证明，基本上10次左右迭代就已经收敛了
    for(int i=1;i<=20;i++)
    {
	System.out.println("This is the "+i+"th job!");
	System.out.println("path1:"+path1);
	System.out.println("path2:"+path2);
        Configuration conf = new Configuration();
    	Job job = new Job(conf, "PageRank");
        path2=paths+i;
    	job.setJarByClass(PageRank.class);
    	job.setMapperClass(MyMapper.class);
    	job.setCombinerClass(MyReducer.class);
    	job.setReducerClass(MyReducer.class);
    	job.setOutputKeyClass(Text.class);
    	job.setOutputValueClass(Text.class);
    	FileInputFormat.addInputPath(job, new Path(path1));
    	FileOutputFormat.setOutputPath(job, new Path(path2));
        path1=path2;
    	job.waitForCompletion(true);
	System.out.println(i+"th end!");
  }
 }	
}